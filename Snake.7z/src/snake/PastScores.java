package snake;

import java.awt.Dimension;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.*;

public class PastScores implements ActionListener {

    private ArrayList<Integer> Score = new ArrayList<Integer>();

    PastScores() {
        try {
            //create and set up window
            JFrame f = new JFrame();
            f.setSize(500, 500);
            f.setLayout(null);
            f.setVisible(true);
            
            //when the button is clicked, return to main menu
            JButton b = new JButton("Return to Main Manu");
            b.setBounds(80, 420, 300, 30);
            b.addActionListener((ActionListener) this);
            f.add(b);
            File file = new File("Scores.txt");
            Scanner sc = new Scanner(file);
            int i = 0;
            
            //set up text area with a scroll bar
            JTextArea textarea = new JTextArea();            
            JScrollPane scrollPane = new JScrollPane(textarea);
            scrollPane.setBounds(5, 5, 450, 400);
            f.add(scrollPane);
            //disable user to edit the scores displaying
            textarea.setEditable(false);
            //scan "Scores.txt" file and store scores in an ArrayList
            while (sc.hasNextLine()) {
                String nextLine = sc.nextLine();
                Score.add(Integer.valueOf(nextLine));
                //output scores on the text area
                textarea.append(Score.get(i) + "\n");
                i++;

            }

        } catch (FileNotFoundException ex) {
            Logger.getLogger(PastScores.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void actionPerformed(ActionEvent e) {
        //open user manuel when "Return to Main Menu button" is clicked
        new UserManual().setVisible(true);
    }

    public static void PastScores() {
        new PastScores();
    }
}
