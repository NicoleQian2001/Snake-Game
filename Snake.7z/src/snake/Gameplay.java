package snake;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;
import java.util.StringTokenizer;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.Timer;

public class Gameplay extends JPanel implements KeyListener, ActionListener {

    private int[] Xsnake = new int[750];
    private int[] Ysnake = new int[750];

    private boolean left = false;
    private boolean right = false;
    private boolean up = false;
    private boolean down = false;

    private ImageIcon righthead;
    private ImageIcon uphead;
    private ImageIcon downhead;
    private ImageIcon lefthead;
    private ImageIcon snakebody;

    private int LengthSnake = 3;
    private int moves = 0;
    private Timer timer;
    private int delay = 100;
    
    //pixel positions that the coin can randomly generated from
    private int[] Xcoin = {25, 50, 75, 100, 125, 150, 175, 200, 225, 250, 275, 300, 325, 350, 375, 400, 425, 450, 475, 500, 525, 550, 575, 600, 625, 650, 675, 700, 725, 750, 775, 800, 825, 850};
    private int[] Ycoin = {75, 100, 125, 150, 175, 200, 225, 250, 275, 300, 325, 350, 375, 400, 425, 450, 475, 500, 525, 550, 575, 600, 625};
    
    private ArrayList<Integer> maxScore = new ArrayList<Integer>();
    private ArrayList<String> names = new ArrayList<String>();
    private ArrayList<String> highestScores = new ArrayList<String>();

    private ImageIcon coin = new ImageIcon("coin.png");
    
    //randomly generates coin positions
    private Random random = new Random();
    private int x = random.nextInt(34);
    private int y = random.nextInt(23);
    private int scores = 0;
    public ImageIcon titleImage;
    private boolean isRunning = true;
    private boolean isPlaying = true;

    public boolean isRunning() {
        if (left == right == up == down == false) {
            return false;
        }
        return true;
    }

    public Gameplay() {
        addKeyListener(this);
        //formality
        setFocusable(true);
        setFocusTraversalKeysEnabled(false);
        //instantiate timer class
        timer = new Timer(delay, this);
        timer.start();
    }

    public void checkMaxScore() {
        try {
            //read "Scores.txt" file
            File file = new File("Scores.txt");
            int count = 0;
            Scanner input = new Scanner(file);
            //while there is more line in the file, keep scanning and adding scores to int array maxScore 
            while (input.hasNextLine()) {
                String nextLine = input.nextLine();
                if (!nextLine.equals("")) {
                    //convert a string named "nextLine" to a Integer instance
                    maxScore.add(Integer.valueOf(nextLine));
                    count++;
                }
            }
            // scanning stopped
            input.close();

            //the first integer in maxScore array is set to the highest score
            //find the highest score and set it to the first integer
            for (int j = 0; j < count; j++) {
                if (maxScore.get(j) > maxScore.get(0)) {
                    maxScore.set(0, maxScore.get(j));
                }
            }
            //update the highest score when current score is larger than it
            if (scores > maxScore.get(0)) {
                maxScore.set(0, scores);
            }

        } catch (FileNotFoundException ex) {
            Logger.getLogger(Gameplay.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void highestScore() throws IOException {
        //if the user set a new highest score, a input dialog will ask the user for his/her name
        if (maxScore.get(0) == scores) {
            try {
                String name = JOptionPane.showInputDialog("You have set the highest score! What is your name?");

                //if the user entered his/her name, show "Thank you, your name and score have been recorded!" message
                if (name.length() > 0) {
                    JOptionPane.showMessageDialog(this, "Thank you, your name and score have been recorded!");
                } else {
                    //if input dialog is empty, new input dialog pops up to ask for his/her name
                    name = JOptionPane.showInputDialog("Please enter your name!");
                }

                //write the user name and new highest score into a delimited file
                File f1 = new File("HighestScores.txt");
                FileWriter fw = new FileWriter(f1, true);
                PrintWriter write = new PrintWriter(fw);
                write.println(name + ";" + scores);
                write.close();
            } catch (FileNotFoundException ex) {
                Logger.getLogger(Gameplay.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    public void BubbleSort(ArrayList<String> names, int a) {
        try {
            //read delimited file "HighestScore.txt" 
            File f1 = new File("HighestScores.txt");
            Scanner sc = new Scanner(f1);
            a = names.size();
            while (sc.hasNextLine()) {
                String fileRead = sc.nextLine();
                StringTokenizer tokenizer = new StringTokenizer(fileRead, ";");
                //store user names in an ArrayList
                names.add(tokenizer.nextToken());
                //store user scores in an ArrayList
                highestScores.add(tokenizer.nextToken());
            }
            sc.close();     
        } catch (FileNotFoundException ex) {
            Logger.getLogger(Gameplay.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            String temp;
            a = names.size();
            //determine when the sort is finished
            boolean flag = true;

            //one pass of bubble sort
            //after this pass, the name ranked the most alphabetically behind goes to the end
            while (flag) {
                flag = false;
                for (int i = 0; i < a - 1; i++) {
                    //string comparison that returns positive number if names.get(i) is greater than names.get(i+1)
                    if (names.get(i).compareToIgnoreCase(names.get(i + 1)) > 0) {
                        //swapping
                        temp = names.get(i);
                        names.set(i, names.get(i + 1));
                        names.set(i + 1, temp);
                        flag = true;
                    }
                }
            }
        }
    }

    public void paint(Graphics g) {

        checkMaxScore();

        //if the game has not started, set the position of the snake set to below
        //the width of a circle is 20, so difference in position between each circle is 20
        if (moves == 0) {
            Xsnake[2] = 80;
            Xsnake[1] = 60;
            Xsnake[0] = 100;

            Ysnake[2] = 125;
            Ysnake[1] = 125;
            Ysnake[0] = 125;
        }
        //set title image boarder
        g.setColor(Color.WHITE);
        g.drawRect(24, 10, 851, 55);

        //draw the title image
        titleImage = new ImageIcon("title.jpg");
        titleImage.paintIcon(this, g, 25, 11);

        //draw border for gameplay
        g.setColor(Color.WHITE);
        g.drawRect(24, 74, 851, 577);

        //draw a rectangle background as game canvas
        g.setColor(Color.black);
        g.fillRect(25, 75, 850, 575);

        //draw scores
        g.setColor(Color.white);
        g.setFont(new Font("arial", Font.PLAIN, 14));
        g.drawString("Scores: " + scores, 780, 30);

        //draw highest score
        g.setColor(Color.white);
        g.setFont(new Font("arial", Font.PLAIN, 14));
        g.drawString("Highest score: " + maxScore.get(0), 760, 50);
        
        righthead = new ImageIcon("righthead.png");
        //the head of the snake is store in the first(0) spot in the array
        righthead.paintIcon(this, g, Xsnake[0], Ysnake[0]);

        for (int a = 0; a < LengthSnake; a++) {
            //if the snake is moving right, its head is "righthead.png" image 
            if (a == 0 && right) {
                righthead = new ImageIcon("righthead.png");
                righthead.paintIcon(this, g, Xsnake[a], Ysnake[a]);
            }
            //if the snake is moving left, its head is "lefthead.png" image
            if (a == 0 && left) {
                lefthead = new ImageIcon("lefthead.png");
                lefthead.paintIcon(this, g, Xsnake[a], Ysnake[a]);
            }
            //if the snake is moving up, its head is "uphead.png" image
            if (a == 0 && up) {
                uphead = new ImageIcon("uphead.png");
                uphead.paintIcon(this, g, Xsnake[a], Ysnake[a]);
            }
            //if the snake is moving up, its head is "uphead.png" image
            if (a == 0 && down) {
                downhead = new ImageIcon("downhead.png");
                downhead.paintIcon(this, g, Xsnake[a], Ysnake[a]);
            }
            //draw the body of the snake, which has a index not equal to 0
            if (a != 0) {
                snakebody = new ImageIcon("snakebody.png");
                snakebody.paintIcon(this, g, Xsnake[a], Ysnake[a]);
            }
        }
        //check if snake head collides with the pick-up
        //if so, snake length increases by 1, and the pick-up re-occur at a random position
        if (Xcoin[x] == Xsnake[0] && Ycoin[y] == Ysnake[0]) {
            scores++;
            LengthSnake++;
            x = random.nextInt(34);
            y = random.nextInt(23);
        }
        coin.paintIcon(this, g, Xcoin[x], Ycoin[y]);

        //check if snake head collides with snake body
        // if they collide, the snake stops moving, "game over" and "press space key to restart" appear on screen
        for (int b = 1; b < LengthSnake; b++) {
            if (Xsnake[b] == Xsnake[0] && Ysnake[b] == Ysnake[0]) {
                right = false;
                left = false;
                up = false;
                down = false;

                //set "Game Over" in white, bold, and 50-sized arial font
                g.setColor(Color.white);
                g.setFont(new Font("arial", Font.BOLD, 50));
                g.drawString("Game Over", 300, 300);

                //set "Press space to restart" in white, bold, and 20-sized arial font
                g.setFont(new Font("arial", Font.BOLD, 20));
                g.drawString("Press space to restart", 350, 340);

                //record user scores in "Scores.txt"
                // each score per line
                File file = new File("Scores.txt");
                if (isPlaying) {
                    try {
                        FileWriter fw = new FileWriter(file, true);
                        PrintWriter user = new PrintWriter(fw);
                        user.println(scores);
                        user.close();
                    } catch (Exception ex) {
                        Logger.getLogger(Gameplay.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }
                isRunning = false;
                isPlaying = false;
                break;
            }
        }
        g.dispose();
    }

    public void keyTyped(KeyEvent e) {
    }

    public void actionPerformed(ActionEvent e) {
        timer.start();
        //when the game is running, arrow keys enable the snake to run continuously in the direction that they point at
        //but when game is over(isRunning == false: the snake head collides with snake body), pressing arrow keys will not work 
        if (isRunning == true) {
            if (right) {
                //moves snake head to right
                for (int r = LengthSnake - 1; r >= 0; r--) {
                    Ysnake[r + 1] = Ysnake[r];
                }

                for (int r = LengthSnake; r >= 0; r--) {
                    if (r == 0) {
                        //moves snake head right 25 pixels each time and snake body closely follows
                        Xsnake[r] = Xsnake[r] + 25;
                    } else {
                        Xsnake[r] = Xsnake[r - 1];
                    }
                    //if the snake goes off screen on the right side(where the pixel is larger than 850), it enters the screen from left(where the pixel is less than 25)
                    if (Xsnake[r] > 850) {
                        Xsnake[r] = 25;
                    }
                }
            }
            if (left) {
                for (int r = LengthSnake - 1; r >= 0; r--) {
                    Ysnake[r + 1] = Ysnake[r];
                }
                for (int r = LengthSnake; r >= 0; r--) {
                    //moves snake head left 25 pixels each time, and snake body closely follows
                    if (r == 0) {
                        Xsnake[r] = Xsnake[r] - 25;
                    } else {
                        Xsnake[r] = Xsnake[r - 1];
                    }
                    //if the snake goes off screen on the left side, it enters the screen on the right
                    if (Xsnake[r] < 25) {
                        Xsnake[r] = 850;
                    }
                }
            }
            if (down) {
                for (int r = LengthSnake - 1; r >= 0; r--) {
                    Xsnake[r + 1] = Xsnake[r];
                }
                for (int r = LengthSnake; r >= 0; r--) {
                    //moves snake head down 25 pixels each time and snake body closely follows
                    if (r == 0) {
                        Ysnake[r] = Ysnake[r] + 25;
                    } else {
                        Ysnake[r] = Ysnake[r - 1];
                    }
                    //if the snake goes off screen down the screen, it enters the screen from top
                    if (Ysnake[r] > 625) {
                        Ysnake[r] = 75;
                    }
                }
            }
            if (up) {
                for (int r = LengthSnake - 1; r >= 0; r--) {
                    Xsnake[r + 1] = Xsnake[r];
                }
                for (int r = LengthSnake; r >= 0; r--) {
                    //moves snake head up 25 pixels each time and snake body closely follows
                    if (r == 0) {
                        Ysnake[r] = Ysnake[r] - 25;
                    } else {
                        Ysnake[r] = Ysnake[r - 1];
                    }
                    //if the snake goes off screen from top, it enters the screen from bottom
                    if (Ysnake[r] < 75) {
                        Ysnake[r] = 625;
                    }
                }
            }
        }
        repaint();
    }

    public void keyPressed(KeyEvent e) {
        //only when user is not playing the game(when the snake head collides with its tail), pressing the space key can restart the game 
        if (isPlaying == false) {
            if (e.getKeyCode() == KeyEvent.VK_SPACE) {
                //call highestScore method
                try {
                    highestScore();
                } catch (IOException ex) {
                    Logger.getLogger(Gameplay.class.getName()).log(Level.SEVERE, null, ex);
                }

                //call bubble sort to sort names alphabetically in "HighestScores.txt" file
                BubbleSort(names, names.size() - 1);
                //display the sorted user names from "HighestScores.txt" in the output
                System.out.println("Sorting user names are: ");
                for (int k = 0; k < names.size(); k++) {
                    System.out.println(names.get(k));
                }

                //set the snake to initial position and length
                moves = 0;
                scores = 0;
                LengthSnake = 3;
                repaint();
                isRunning = true;
                isPlaying = true;
            }
        }

        //moves snake right when right arrow key is pressed
        if (e.getKeyCode() == KeyEvent.VK_RIGHT) {
            moves++;
            right = true;

            //if the snake is moving right, it can't move left when user presses the corresponding arrow key
            if (!left) {
                right = true;
            } else {
                right = false;
                left = true;
            }
            up = false;
            down = false;
        }
        //moves snake left when left arrow key is pressed
        if (e.getKeyCode() == KeyEvent.VK_LEFT) {
            moves++;
            left = true;

            //if the snake is moving left, it can't move right when user presses right arrow key
            if (!right) {
                left = true;
            } else {
                left = false;
                right = true;
            }
            up = false;
            down = false;
        }

        //moves snake up when up arrow key is pressed
        if (e.getKeyCode() == KeyEvent.VK_UP) {
            moves++;
            up = true;

            //if the snake is moving up, it can't move down when user presses the corresponding arrow key
            if (!down) {
                up = true;
            } else {
                up = false;
                down = true;
            }
            left = false;
            right = false;
        }

        //moves snake down when down arrow key is pressed
        if (e.getKeyCode() == KeyEvent.VK_DOWN) {
            moves++;
            down = true;

            //if the snake is moving down, it can't move up when user presses the corresponding arrow key
            if (!up) {
                down = true;
            } else {
                down = false;
                up = true;
            }
            left = false;
            right = false;
        }
    }

    public void keyReleased(KeyEvent e) {
    }
}
